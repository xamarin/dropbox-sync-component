#import "InputTaskCell.h"

@implementation InputTaskCell

@end
