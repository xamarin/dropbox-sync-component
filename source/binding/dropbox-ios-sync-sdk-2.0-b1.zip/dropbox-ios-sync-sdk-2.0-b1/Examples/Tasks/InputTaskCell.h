#import <UIKit/UIKit.h>

@interface InputTaskCell : UITableViewCell

@property (nonatomic, retain) IBOutlet UITextField *textField;

@end
