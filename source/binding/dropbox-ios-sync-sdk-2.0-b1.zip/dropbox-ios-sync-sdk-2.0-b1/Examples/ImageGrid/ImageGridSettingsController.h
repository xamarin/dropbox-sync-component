#import "SettingsController.h"

@interface ImageGridSettingsController : SettingsController

@end
