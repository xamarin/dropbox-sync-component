#import <UIKit/UIKit.h>
#import "FolderController.h"
@interface ImageGridViewController : UICollectionViewController <FolderController,
UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@end
