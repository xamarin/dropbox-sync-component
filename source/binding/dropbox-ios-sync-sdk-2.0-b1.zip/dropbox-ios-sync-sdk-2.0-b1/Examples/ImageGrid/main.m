#import <UIKit/UIKit.h>

#import "ImageGridAppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
		return UIApplicationMain(argc, argv, nil, NSStringFromClass([ImageGridAppDelegate class]));
	}
}
