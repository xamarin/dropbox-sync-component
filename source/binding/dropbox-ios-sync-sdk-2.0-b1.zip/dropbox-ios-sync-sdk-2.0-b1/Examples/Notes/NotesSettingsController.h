#import "SettingsController.h"

@interface NotesSettingsController : SettingsController

@end
