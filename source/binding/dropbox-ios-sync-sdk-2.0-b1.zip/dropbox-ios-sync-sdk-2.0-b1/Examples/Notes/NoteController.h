#import <Dropbox/Dropbox.h>

@interface NoteController : UIViewController

- (id)initWithFile:(DBFile *)file;

@end
